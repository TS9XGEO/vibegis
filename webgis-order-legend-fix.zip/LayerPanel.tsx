/**
 * Layer panel: visibility, opacity, drag-to-reorder, legend, zoom-to-extent.
 *
 * Reordering is pure state — dnd-kit hands back an index pair, the store
 * swaps the array, and the Scene re-renders in the new order. Nothing touches
 * Cesium directly.
 */
import { useState } from 'react'
import {
  ActionIcon,
  Alert,
  Badge,
  Box,
  Checkbox,
  Collapse,
  Group,
  Image,
  Loader,
  Paper,
  ScrollArea,
  Slider,
  Stack,
  Switch,
  Text,
  Tooltip,
} from '@mantine/core'
import { useDisclosure } from '@mantine/hooks'
import {
  IconChevronDown,
  IconChevronRight,
  IconChevronUp,
  IconCurrentLocation,
  IconGripVertical,
  IconList,
} from '@tabler/icons-react'
import {
  DndContext,
  KeyboardSensor,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core'
import { restrictToVerticalAxis } from '@dnd-kit/modifiers'
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { Rectangle } from 'cesium'
import { useCesium } from 'resium'

import type { LayerState } from './wms'
import { WMS_URL, useApp } from './wms'

/** MapServer renders the whole legend for a layer, all classes included. */
function legendUrl(layer: string) {
  return (
    `${WMS_URL}?service=WMS&version=1.3.0&request=GetLegendGraphic` +
    `&layer=${encodeURIComponent(layer)}&format=image/png&sld_version=1.1.0`
  )
}

function LayerRow({ layer }: { layer: LayerState }) {
  const toggle = useApp((s) => s.toggle)
  const setOpacity = useApp((s) => s.setOpacity)
  const move = useApp((s) => s.move)
  const { camera } = useCesium()
  const [legendOpen, setLegendOpen] = useState(false)

  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: layer.name,
  })

  const flyTo = () => {
    if (!camera || !layer.bbox) return
    const { west, south, east, north } = layer.bbox
    camera.flyTo({
      destination: Rectangle.fromDegrees(west, south, east, north),
      duration: 1.2,
    })
  }

  return (
    <Box
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.45 : 1,
        position: 'relative',
        zIndex: isDragging ? 5 : 'auto',
      }}
      px={4}
      py={2}
    >
      <Group gap={4} wrap="nowrap">
        <ActionIcon
          variant="subtle"
          color="gray"
          size="sm"
          // touchAction:none is REQUIRED by dnd-kit's PointerSensor. Without it
          // the browser claims the gesture for scrolling and no drag starts.
          style={{ cursor: 'grab', touchAction: 'none' }}
          {...attributes}
          {...listeners}
        >
          <IconGripVertical size={14} />
        </ActionIcon>

        <Checkbox size="xs" checked={layer.visible} onChange={() => toggle(layer.name)} />

        <Tooltip label={layer.name} openDelay={500} withArrow>
          <Text size="sm" style={{ flex: 1, minWidth: 0 }} truncate>
            {layer.title}
          </Text>
        </Tooltip>

        <Tooltip label="Legende" withArrow>
          <ActionIcon
            variant="subtle"
            color={legendOpen ? 'blue' : 'gray'}
            size="sm"
            onClick={() => setLegendOpen((o) => !o)}
          >
            <IconList size={13} />
          </ActionIcon>
        </Tooltip>

        {layer.bbox && (
          <Tooltip label="Auf Layer zoomen" withArrow>
            <ActionIcon variant="subtle" color="gray" size="sm" onClick={flyTo}>
              <IconCurrentLocation size={13} />
            </ActionIcon>
          </Tooltip>
        )}

        <ActionIcon variant="subtle" color="gray" size="sm" onClick={() => move(layer.name, -1)}>
          <IconChevronUp size={13} />
        </ActionIcon>
        <ActionIcon variant="subtle" color="gray" size="sm" onClick={() => move(layer.name, 1)}>
          <IconChevronDown size={13} />
        </ActionIcon>
      </Group>

      {layer.visible && (
        <Group gap={8} pl={30} pr={4} pt={2} wrap="nowrap">
          <Slider
            size="xs"
            style={{ flex: 1 }}
            min={0}
            max={100}
            value={Math.round(layer.opacity * 100)}
            onChange={(v) => setOpacity(layer.name, v / 100)}
            label={null}
          />
          <Text size="10px" c="dimmed" w={30} ta="right">
            {Math.round(layer.opacity * 100)}%
          </Text>
        </Group>
      )}

      <Collapse in={legendOpen}>
        <Box pl={30} pt={4} pb={2}>
          <Image
            src={legendUrl(layer.name)}
            alt={`Legende ${layer.title}`}
            fit="contain"
            style={{ maxWidth: '100%', background: 'rgba(255,255,255,.04)', borderRadius: 4 }}
            fallbackSrc=""
          />
        </Box>
      </Collapse>
    </Box>
  )
}

export default function LayerPanel() {
  const layers = useApp((s) => s.layers)
  const loading = useApp((s) => s.loading)
  const error = useApp((s) => s.error)
  const reorder = useApp((s) => s.reorder)
  const [opened, { toggle: toggleOpen }] = useDisclosure(true)

  const osmVisible = useApp((s) => s.osmVisible)
  const setOsm = useApp((s) => s.setOsm)
  const terrainOn = useApp((s) => s.terrainOn)
  const setTerrain = useApp((s) => s.setTerrain)
  const terrainAvailable = useApp((s) => s.terrainAvailable)
  const tilesOn = useApp((s) => s.tilesOn)
  const setTiles = useApp((s) => s.setTiles)
  const tilesAvailable = useApp((s) => s.tilesAvailable)
  const lighting = useApp((s) => s.lighting)
  const setLighting = useApp((s) => s.setLighting)

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 3 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  )

  function onDragEnd(e: DragEndEvent) {
    const { active, over } = e
    if (!over || active.id === over.id) return
    const from = layers.findIndex((l) => l.name === active.id)
    const to = layers.findIndex((l) => l.name === over.id)
    if (from >= 0 && to >= 0) reorder(from, to)
  }

  return (
    <Paper
      shadow="md"
      radius="md"
      withBorder
      style={{
        position: 'absolute',
        top: 10,
        left: 10,
        zIndex: 20,
        width: 320,
        maxHeight: 'calc(100% - 20px)',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: 'rgba(20,22,28,0.92)',
        backdropFilter: 'blur(8px)',
      }}
    >
      <Group
        justify="space-between"
        px="sm"
        py={8}
        onClick={toggleOpen}
        style={{ cursor: 'pointer', borderBottom: '1px solid rgba(255,255,255,.1)' }}
      >
        <Group gap={6}>
          {opened ? <IconChevronDown size={14} /> : <IconChevronRight size={14} />}
          <Text fw={600} size="sm">Layer</Text>
        </Group>
        {!loading && <Badge size="xs" variant="light">{layers.length}</Badge>}
      </Group>

      <Collapse in={opened}>
        <ScrollArea.Autosize mah="calc(100vh - 140px)">
          <Stack gap="xs" p="xs">
            <Box>
              <Text size="10px" fw={700} c="dimmed" tt="uppercase" mb={4}>Daten</Text>

              {loading && (
                <Group gap={8}><Loader size="xs" /><Text size="xs" c="dimmed">lade…</Text></Group>
              )}

              {error && (
                <Alert color="red" variant="light" p="xs">
                  <Text size="xs">{error}</Text>
                </Alert>
              )}

              {!loading && !error && (
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={onDragEnd}
                  modifiers={[restrictToVerticalAxis]}
                >
                  <SortableContext
                    items={layers.map((l) => l.name)}
                    strategy={verticalListSortingStrategy}
                  >
                    {layers.map((l) => <LayerRow key={l.name} layer={l} />)}
                  </SortableContext>
                </DndContext>
              )}

              <Text size="10px" c="dimmed" mt={6}>
                Oben = wird zuerst gezeichnet. Ziehen oder Pfeile benutzen.
              </Text>
            </Box>

            <Box>
              <Text size="10px" fw={700} c="dimmed" tt="uppercase" mb={4}>3D</Text>
              <Stack gap={6}>
                <Switch
                  size="xs"
                  label="Gelände (quantized-mesh)"
                  checked={terrainOn}
                  disabled={terrainAvailable === false}
                  onChange={(e) => setTerrain(e.currentTarget.checked)}
                />
                <Switch
                  size="xs"
                  label="3D-Gebäude"
                  checked={tilesOn}
                  disabled={tilesAvailable === false}
                  onChange={(e) => setTiles(e.currentTarget.checked)}
                />
                <Switch
                  size="xs"
                  label="Beleuchtung"
                  checked={lighting}
                  onChange={(e) => setLighting(e.currentTarget.checked)}
                />
              </Stack>
              {terrainAvailable === false && (
                <Text size="10px" c="dimmed" mt={4}>
                  Keine Kacheln unter /terrain — ctb-Profil noch nicht gelaufen.
                </Text>
              )}
            </Box>

            <Box>
              <Text size="10px" fw={700} c="dimmed" tt="uppercase" mb={4}>Hintergrund</Text>
              <Switch
                size="xs"
                label="OpenStreetMap (extern)"
                checked={osmVisible}
                onChange={(e) => setOsm(e.currentTarget.checked)}
              />
            </Box>
          </Stack>
        </ScrollArea.Autosize>
      </Collapse>
    </Paper>
  )
}
