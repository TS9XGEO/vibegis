/**
 * WMS capabilities parsing + the application store.
 *
 * The layer list is never hardcoded: it is read from MapServer's
 * GetCapabilities document, so adding a LAYER to the mapfile is enough to make
 * it appear in the UI.
 */
import { create } from 'zustand'

export const WMS_URL = '/mapserver'
export const TERRAIN_URL = '/terrain'
export const TILES3D_URL = '/3dtiles/tileset.json'

export interface Bbox {
  west: number
  south: number
  east: number
  north: number
}

/** A node exactly as it appears in the capabilities document. */
export interface CapNode {
  name: string | null
  title: string
  bbox: Bbox | null
  children: CapNode[]
}

/** A drawable layer plus its UI state. */
export interface LayerState {
  name: string
  title: string
  bbox: Bbox | null
  group: string | null
  visible: boolean
  opacity: number
}

// ---------------------------------------------------------------- parsing

function childrenNamed(el: Element, localName: string): Element[] {
  return Array.from(el.children).filter((c) => c.localName === localName)
}

function textOf(el: Element, localName: string): string | null {
  const found = childrenNamed(el, localName)[0]
  return found ? found.textContent!.trim() : null
}

function parseBbox(el: Element): Bbox | null {
  const box = childrenNamed(el, 'EX_GeographicBoundingBox')[0]
  if (!box) return null
  const num = (t: string) => Number(textOf(box, t))
  const b: Bbox = {
    west: num('westBoundLongitude'),
    east: num('eastBoundLongitude'),
    south: num('southBoundLatitude'),
    north: num('northBoundLatitude'),
  }
  return Object.values(b).some(Number.isNaN) ? null : b
}

function parseNode(el: Element): CapNode {
  return {
    name: textOf(el, 'Name'),
    title: textOf(el, 'Title') ?? textOf(el, 'Name') ?? '(ohne Titel)',
    bbox: parseBbox(el),
    children: childrenNamed(el, 'Layer').map(parseNode),
  }
}

export async function fetchCapabilities(signal?: AbortSignal): Promise<CapNode> {
  const url = `${WMS_URL}?service=WMS&version=1.3.0&request=GetCapabilities`
  const res = await fetch(url, { signal })
  if (!res.ok) throw new Error(`GetCapabilities: HTTP ${res.status}`)

  const doc = new DOMParser().parseFromString(await res.text(), 'text/xml')
  if (doc.getElementsByTagName('parsererror').length) {
    throw new Error('Capabilities ist kein gültiges XML')
  }
  const cap = doc.getElementsByTagNameNS('*', 'Capability')[0]
  if (!cap) throw new Error('Kein <Capability>-Element gefunden')
  const root = childrenNamed(cap, 'Layer')[0]
  if (!root) throw new Error('Kein Wurzel-Layer gefunden')
  return parseNode(root)
}

/** Flatten to drawable leaves, remembering which group each came from. */
export function flattenLeaves(node: CapNode, group: string | null = null): LayerState[] {
  if (node.children.length === 0) {
    if (!node.name) return []
    return [{
      name: node.name,
      title: node.title,
      bbox: node.bbox,
      group,
      visible: !DEFAULT_OFF.has(node.name),
      opacity: 1,
    }]
  }
  // the outermost node is the service itself, not a real group
  const nextGroup = node.name ? node.title : group
  return node.children.flatMap((c) => flattenLeaves(c, nextGroup))
}

const DEFAULT_OFF = new Set(['dem'])

// ------------------------------------------------------------------ store

interface AppState {
  layers: LayerState[]          // index 0 draws on TOP
  loading: boolean
  error: string | null

  osmVisible: boolean
  terrainOn: boolean
  terrainAvailable: boolean | null
  tilesOn: boolean
  tilesAvailable: boolean | null
  lighting: boolean

  load: () => Promise<void>
  toggle: (name: string) => void
  setOpacity: (name: string, opacity: number) => void
  reorder: (from: number, to: number) => void
  move: (name: string, delta: number) => void

  setOsm: (v: boolean) => void
  setTerrain: (v: boolean) => void
  setTiles: (v: boolean) => void
  setLighting: (v: boolean) => void
  probeAssets: () => Promise<void>
}

async function urlExists(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, { cache: 'no-store' })
    return res.ok
  } catch {
    return false
  }
}

export const useApp = create<AppState>((set, get) => ({
  layers: [],
  loading: true,
  error: null,

  osmVisible: true,
  terrainOn: false,
  terrainAvailable: null,
  tilesOn: false,
  tilesAvailable: null,
  lighting: false,

  load: async () => {
    set({ loading: true, error: null })
    try {
      const root = await fetchCapabilities()
      // Capabilities list layers in mapfile order, which is bottom-to-top by
      // MapServer convention: landcover, then roads, then buildings on top.
      // The store is top-first, so reverse it — otherwise land cover would
      // default to covering everything beneath it.
      set({ layers: flattenLeaves(root).reverse(), loading: false })
    } catch (err) {
      set({ error: err instanceof Error ? err.message : String(err), loading: false })
    }
  },

  toggle: (name) =>
    set((s) => ({
      layers: s.layers.map((l) => (l.name === name ? { ...l, visible: !l.visible } : l)),
    })),

  setOpacity: (name, opacity) =>
    set((s) => ({
      layers: s.layers.map((l) => (l.name === name ? { ...l, opacity } : l)),
    })),

  reorder: (from, to) =>
    set((s) => {
      if (from === to) return s
      const next = s.layers.slice()
      const [moved] = next.splice(from, 1)
      next.splice(to, 0, moved)
      return { layers: next }
    }),

  move: (name, delta) => {
    const { layers, reorder } = get()
    const i = layers.findIndex((l) => l.name === name)
    const j = i + delta
    if (i < 0 || j < 0 || j >= layers.length) return
    reorder(i, j)
  },

  setOsm: (v) => set({ osmVisible: v }),
  setTerrain: (v) => set({ terrainOn: v }),
  setTiles: (v) => set({ tilesOn: v }),
  setLighting: (v) => set({ lighting: v }),

  probeAssets: async () => {
    const [terrain, tiles] = await Promise.all([
      urlExists(`${TERRAIN_URL}/layer.json`),
      urlExists(TILES3D_URL),
    ])
    set({ terrainAvailable: terrain, tilesAvailable: tiles })
    if (!terrain) set({ terrainOn: false })
    if (!tiles) set({ tilesOn: false })
  },
}))
